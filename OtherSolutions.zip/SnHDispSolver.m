% This is a solver for nonlinear dispersion relationship of Stokes theory.
% The full nonlinear dispersion relationship has h (mean water depth), either T
% (wave period) or omega0 (leading order frequency), and 
% either a or H is given. Results include k, H, a, omega, omega0. 

% Mode 2 only, the first harmonic term's coefficient is given as aw, Hw. 
% Example 1, 
% Results =SnHDispSolver('h',30,'T', 5, 'a',2.5)
% Example 2, 
% Results =SnHDispSolver('h',30,'T', 5, 'H',5)

function [Results] = SnHDispSolver(varargin)
names = varargin(1:2:end);
values = varargin(2:2:end);
for kIn = 1:numel(names)
    switch names{kIn}
        case 'a'
            a = values{kIn};
        case 'H'
            H = values{kIn};
        case 'h'
            h = values{kIn};
        case 'T'
            T = values{kIn};
    end
end
Results.h = h;
Results.T = T;
omega = 2*pi/T;
Results.omega = omega;
syms k
g = 9.81; 
L0 = g*T^2/2/pi;
alpha1 = cosh(2*k*h);
if and(exist('a', 'var') ==1, exist('T', 'var') ==1) 
    % In the work by S and H, the amplitude is the first harmonic wave
    % amplitude combined, therefore it is \widetilde{a} in the manuscript, 
    % and denoted as aw in this code
    aw = a;
    Results.aw = a;
    omega0 = sqrt(g*k*tanh(k*h));
    Results.T = T;
    omega = 2*pi/T;
    
    Results.omega = omega;
    omega2 = k^2*a^2*(2*alpha1^2+7)/4/(alpha1 -1)^2;
    omega4 = (a^4*k^4*(16*alpha1^5 + 68*alpha1^4 -38*alpha1^3 ...
                - 250*alpha1^2 + +55*alpha1+230))/(32*(alpha1 - 1)^5);
    omegaFun = omega0*(1+omega2+omega4) - omega;
    kResults = double(vpasolve(omegaFun, k, [0 Inf]));
    Results.omega0 = sqrt(g*kResults*tanh(kResults*h));
    % Below B33 is equivalent to 
    % B33 = (27-9*sigma^2+9*sigma^4-3*sigma^6)/64/sigma^6;
    B33 = (cosh(2*h*kResults)^3 + 3*cosh(2*h*kResults)^2 + 3*cosh(2*h*kResults) + 2)/(8*(cosh(2*h*kResults) - 1)^3);  
    B55 = (300*cosh(2*h*kResults)^8 + 1579*cosh(2*h*kResults)^7 + 3176*cosh(2*h*kResults)^6 + 2949*cosh(2*h*kResults)^5 ...
            + 1188*cosh(2*h*kResults)^4 + 675*cosh(2*h*kResults)^3 + 1326*cosh(2*h*kResults)^2 + 827*cosh(2*h*kResults) ...
            + 130)*5/((cosh(2*h*kResults) - 1)^6*(12*cosh(2*h*kResults)^2 + 11*cosh(2*h*kResults) + 2)*384);
    
    B53 = (51*cosh(2*h*kResults)^7 + 116*cosh(2*h*kResults)^6 - 211*cosh(2*h*kResults)^5 ...
            -760*cosh(2*h*kResults)^4 - 597*cosh(2*h*kResults)^3 +106*cosh(2*h*kResults)^2 ...
            + 355*cosh(2*h*kResults) + 130)*9/((3*cosh(2*h*kResults) + 2)*(cosh(2*h*kResults) - 1)^6*128);
    Hout = 2*aw+2*B33*kResults^2*aw^3+2*(B53+B55)*kResults^4*aw^5;
    Results.Hw = Hout;
    
elseif and(exist('H', 'var') ==1, exist('T', 'var') ==1)

   omega0 = sqrt(g*k*tanh(k*h));
    Results.T = T;
    omega = 2*pi/T;
    Results.omega = omega;
    syms aw
     
    B33 = (cosh(2*h*k)^3 + 3*cosh(2*h*k)^2 + 3*cosh(2*h*k) + 2)/(8*(cosh(2*h*k) - 1)^3);        
    B55 = (300*cosh(2*h*k)^8 + 1579*cosh(2*h*k)^7 + 3176*cosh(2*h*k)^6 + 2949*cosh(2*h*k)^5 ...
        + 1188*cosh(2*h*k)^4 + 675*cosh(2*h*k)^3 + 1326*cosh(2*h*k)^2 + 827*cosh(2*h*k) ...
        + 130)*5/((cosh(2*h*k) - 1)^6*(12*cosh(2*h*k)^2 + 11*cosh(2*h*k) + 2)*384);
    B53 = (51*cosh(2*h*k)^7 + 116*cosh(2*h*k)^6 - 211*cosh(2*h*k)^5 ...
        -760*cosh(2*h*k)^4 - 597*cosh(2*h*k)^3 +106*cosh(2*h*k)^2 ...
        + 355*cosh(2*h*k) + 130)*9/((3*cosh(2*h*k) + 2)*(cosh(2*h*k) - 1)^6*128);
    Hw = H;
    Results.Hw = Hw;
    Hfun2 = Hw - (2*aw+2*B33*k^2*aw^3+2*(B53+B55)*k^4*aw^5)==0;
    omega2 = k^2*aw^2*(2*alpha1^2+7)/4/(alpha1 -1)^2;
    omega4 = (aw^4*k^4*(16*alpha1^5 + 68*alpha1^4 -38*alpha1^3 ...
                - 250*alpha1^2 + +55*alpha1+230))/(32*(alpha1 - 1)^5);
    omegaFun2 = omega0*(1+omega2+omega4) - omega ==0;      
    S = vpasolve([Hfun2 ==0, omegaFun2==0], [k, aw],[2*pi/L0,H/2]);
    kResults = abs(double(S.k));
    aResults = double(S.aw);
    Results.aw = aResults;
Results.omega0 = sqrt(g*kResults*tanh(kResults*h));

else    
end

Results.k = kResults;
Results.L = 2*pi/kResults;

end


