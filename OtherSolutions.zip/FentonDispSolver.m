% This is a solver for nonlinear dispersion relationship of Stokes theory.
% The full nonlinear dispersion relationship has h (mean water depth), either T
% (wave period) or omega0 (leading order frequency), and 
% either a or H is given. Results include k, H, a, omega, omega0. 
% Mode 1, the first order wave amplitude/height is given as a, H.
% Mode 2, the first harmonic term's coefficient is given as aw, Hw. 
% Example 1, 
% Results =FentonDispSolver('h',1,'T', 5, 'a',0.05, 'mode',1)
% Example 2, % use with caution, it seems not vpasolve not working well
% Results =FentonDispSolver('h',1,'T', 5, 'a',0.05, 'mode',2)
% Example 3, 
% Results =FentonDispSolver('h',1,'T', 5, 'H',0.1, 'mode',1)
% Example 4, 
% Results =FentonDispSolver('h',1,'T', 5, 'H',0.1, 'mode',2)


function [Results] = FentonDispSolver(varargin)
names = varargin(1:2:end);
values = varargin(2:2:end);
for kIn = 1:numel(names)
    switch names{kIn}
        case 'a'
            a = values{kIn};
        case 'H'
            H = values{kIn};
        case 'h'
            h = values{kIn};
        case 'T'
            T = values{kIn};
        case 'mode'
            modeNo = values{kIn};
    end
end
Results.h = h;
Results.T = T;
omega = 2*pi/T;
Results.omega = omega;
syms k
g = 9.81; 
L0 = g*T^2/2/pi;
S = 1/cosh(2*k*h);
alpha = 1/S;
if and(exist('a', 'var') ==1, exist('T', 'var') ==1)
    omega0 = sqrt(g*k*tanh(k*h));
    if modeNo == 1
        omega2Fen = (2+7*S^2)/(4*(1-S)^2);
        omega4Fen = (4+32*S - 116*S^2-400*S^3-71*S^4+146*S^5)/(32*(1-S)^5);
        kResults = double(vpasolve(omega - sqrt(g*k*tanh (k*h))*(1+omega2Fen*(k*a)^2+omega4Fen*(k*a)^4)==0, [0 Inf]));
        Results.a = a;
        Results.H = 2*a;
        S = 1/cosh(2*kResults*h); alpha = 1/S;
        B31 =  -3*(1+3*S+3*S^2+2*S^3)/8/(1-S)^3;
        B53 = 1/(128*(alpha-1)^6*(3*alpha+2)).*9*(-33*alpha^7 ...
        +4 *alpha^6+553*alpha^5+1336*alpha^4+1239*alpha^3+362*alpha^2 ...
        -139*alpha -82);
        B55 =5*(300+1579*S+3176*S.^2+2949*S.^3+1188*S.^4+675*S.^5+ ...
            1326*S.^6+827*S.^7+130*S.^8)./(384*(3+2*S).*(4+S).*(1-S).^6);
        B51 = - B53 - B55;
        Results.aw = a*(1+kResults^2*a^2*B31 + kResults^4*a^4*B51);
    elseif modeNo == 2 % coefficients for given \widetilde{a} as in Zhao and Liu (2021)
        syms a0
        B31 =  -3*(1+3*S+3*S^2+2*S^3)/8/(1-S)^3;
        B53 = 1/(128*(alpha-1)^6*(3*alpha+2)).*9*(-33*alpha^7 ...
            +4 *alpha^6+553*alpha^5+1336*alpha^4+1239*alpha^3+362*alpha^2 ...
            -139*alpha -82);
        B55 =5*(300+1579*S+3176*S.^2+2949*S.^3+1188*S.^4+675*S.^5+ ...
            1326*S.^6+827*S.^7+130*S.^8)./(384*(3+2*S).*(4+S).*(1-S).^6);
        B51 = - B53 - B55;
        a0Fun = a - a0*(1+k^2.*a0^2*B31+k^4.*a0^4*B51);
        omega2Fen = (2+7*S^2)/(4*(1-S)^2);
        omega4Fen = (4+32*S - 116*S^2-400*S^3-71*S^4+146*S^5)/(32*(1-S)^5);
        omegaFun = omega0*(1+omega2Fen+omega4Fen) - omega; 
        Results.aw =a;
        SovResults = vpasolve([a0Fun , omegaFun], [k, a0],[2*pi/L0,a]);
        Results.a = abs(double(SovResults.a0));
        kResults = abs(double(SovResults.k));
        Results.H = 2*Results.a;
        Results.c = Results.omega/kResults;
            
    end
%     kResults = double(vpasolve(omegaFun, k, [0 Inf]));
    Results.omega0 = sqrt(g*kResults*tanh(kResults*h));    
    
    
elseif and(exist('H', 'var') ==1, exist('T', 'var') ==1)

    omega0 = sqrt(g*k*tanh(k*h));   
    Results.a = H/2;
    Results.H = H;            
    a = H/2;
    omega2 = (2+7*S^2)/(4*(1-S)^2); 
    omega4Fen = (4+32*S - 116*S^2-400*S^3-71*S^4+146*S^5)/(32*(1-S)^5);
    omegaFun1 = omega0*(1+k^2*a^2*omega2+k^4*a^4*omega4Fen) - omega ==0;            
    kResults = double(vpasolve(omegaFun1, k, [0 Inf]));
    S = 1/cosh(2*kResults*h); alpha = 1/S;
    B31 =  -3*(1+3*S+3*S^2+2*S^3)/8/(1-S)^3;
    B53 = 1/(128*(alpha-1)^6*(3*alpha+2)).*9*(-33*alpha^7 ...
        +4 *alpha^6+553*alpha^5+1336*alpha^4+1239*alpha^3+362*alpha^2 ...
        -139*alpha -82);
    B55 =5*(300+1579*S+3176*S.^2+2949*S.^3+1188*S.^4+675*S.^5+ ...
        1326*S.^6+827*S.^7+130*S.^8)./(384*(3+2*S).*(4+S).*(1-S).^6);
    B51 = - B53 - B55;
    Results.aw = a*(1+kResults^2*a^2*B31 + kResults^4*a^4*B51);
    Results.omega0 = sqrt(g*kResults*tanh(kResults*h));
    Results.c = Results.omega/kResults;


else    
end

Results.k = kResults;
Results.L = 2*pi/kResults;

end


